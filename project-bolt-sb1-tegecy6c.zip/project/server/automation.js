import cron from 'node-cron';
import Reading from './models/Reading.js';
import Device from './models/Device.js';
import Log from './models/Log.js';
import Settings from './models/Settings.js';
import axios from 'axios';

export function startAutomation(io) {
  // Check every minute for automation triggers
  cron.schedule('* * * * *', async () => {
    try {
      await checkIrrigationNeeds(io);
    } catch (error) {
      console.error('Automation error:', error);
    }
  });

  console.log('Automation system started');
}

async function checkIrrigationNeeds(io) {
  // Get latest sensor reading
  const latestReading = await Reading.findOne().sort({ timestamp: -1 });
  if (!latestReading) return;

  // Get irrigation device
  let device = await Device.findOne({ deviceId: 'irrigation-01' });
  if (!device) {
    device = new Device({
      deviceId: 'irrigation-01',
      name: 'Main Irrigation System',
      type: 'irrigation'
    });
    await device.save();
  }

  // Only act if in auto mode
  if (device.mode !== 'auto') return;

  // Get moisture threshold setting
  const thresholdSetting = await Settings.findOne({ key: 'soil_moisture_threshold' });
  const threshold = thresholdSetting?.value || 30;

  // Check if rain is expected
  const rainExpected = await checkRainForecast();

  // Low moisture alert
  if (latestReading.soilMoisture < threshold) {
    const alert = new Log({
      deviceId: 'farm-sensor-01',
      action: 'Low soil moisture detected',
      reason: `Moisture level: ${latestReading.soilMoisture}%`,
      type: 'alert'
    });
    await alert.save();
    io.emit('newAlert', alert);

    // Turn on irrigation if not raining and device is off
    if (!rainExpected && device.status === 'OFF') {
      device.status = 'ON';
      device.lastUpdated = new Date();
      await device.save();

      const log = new Log({
        deviceId: device.deviceId,
        action: 'ON irrigation',
        reason: `Auto: Low moisture (${latestReading.soilMoisture}%)`,
        type: 'irrigation'
      });
      await log.save();

      io.emit('deviceUpdate', device);
      io.emit('newLog', log);
    }
  }

  // Turn off irrigation if moisture is adequate
  if (latestReading.soilMoisture > threshold + 10 && device.status === 'ON') {
    device.status = 'OFF';
    device.lastUpdated = new Date();
    await device.save();

    const log = new Log({
      deviceId: device.deviceId,
      action: 'OFF irrigation',
      reason: `Auto: Adequate moisture (${latestReading.soilMoisture}%)`,
      type: 'irrigation'
    });
    await log.save();

    io.emit('deviceUpdate', device);
    io.emit('newLog', log);
  }
}

async function checkRainForecast() {
  try {
    const apiKeySetting = await Settings.findOne({ key: 'openweather_api_key' });
    if (!apiKeySetting) return false;

    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/forecast?q=New York&appid=${apiKeySetting.value}&units=metric`
    );

    // Check next 6 hours for rain
    const next6Hours = response.data.list.slice(0, 2);
    return next6Hours.some(item => item.pop > 0.3); // 30% rain probability
  } catch (error) {
    console.error('Weather check error:', error);
    return false;
  }
}