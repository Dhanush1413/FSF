import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import sensorRoutes from './routes/sensor.js';
import deviceRoutes from './routes/device.js';
import weatherRoutes from './routes/weather.js';
import alertRoutes from './routes/alert.js';
import settingsRoutes from './routes/settings.js';
import { initializeWebSocket } from './websocket.js';
import { startAutomation } from './automation.js';

dotenv.config();

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/smart-agriculture', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Routes
app.use('/api/sensor', sensorRoutes);
app.use('/api/device', deviceRoutes);
app.use('/api/weather', weatherRoutes);
app.use('/api/alert', alertRoutes);
app.use('/api/settings', settingsRoutes);

// Initialize WebSocket
initializeWebSocket(io);

// Start automation system
startAutomation(io);

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export { io };