import express from 'express';
import axios from 'axios';
import Settings from '../models/Settings.js';

const router = express.Router();

// Get weather forecast
router.get('/forecast', async (req, res) => {
  try {
    const apiKeySetting = await Settings.findOne({ key: 'openweather_api_key' });
    
    if (!apiKeySetting) {
      return res.status(400).json({ error: 'OpenWeather API key not configured' });
    }

    const API_KEY = apiKeySetting.value;
    const city = 'New York'; // Default city, could be configurable
    
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=metric`
    );

    const forecast = response.data.list.slice(0, 10).map(item => ({
      timestamp: new Date(item.dt * 1000),
      temperature: item.main.temp,
      humidity: item.main.humidity,
      description: item.weather[0].description,
      rainProbability: item.pop * 100,
      rain: item.rain?.['3h'] || 0
    }));

    res.json(forecast);
  } catch (error) {
    console.error('Weather API error:', error.message);
    res.status(500).json({ error: 'Failed to fetch weather data' });
  }
});

export default router;