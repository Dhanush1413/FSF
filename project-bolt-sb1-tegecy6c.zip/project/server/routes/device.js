import express from 'express';
import Device from '../models/Device.js';
import Log from '../models/Log.js';
import { io } from '../index.js';

const router = express.Router();

// Get all devices
router.get('/', async (req, res) => {
  try {
    const devices = await Device.find();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update device status
router.put('/:deviceId', async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { status, mode } = req.body;
    
    const device = await Device.findOneAndUpdate(
      { deviceId },
      { status, mode, lastUpdated: new Date() },
      { new: true, upsert: true }
    );

    // Log the action
    const log = new Log({
      deviceId,
      action: `${status} irrigation`,
      reason: mode === 'manual' ? 'Manual control' : 'Automatic control',
      type: 'irrigation'
    });
    await log.save();

    // Emit real-time update
    io.emit('deviceUpdate', device);
    io.emit('newLog', log);

    res.json(device);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get device logs
router.get('/:deviceId/logs', async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { limit = 50 } = req.query;
    
    const logs = await Log.find({ deviceId })
      .sort({ timestamp: -1 })
      .limit(parseInt(limit));
    
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;