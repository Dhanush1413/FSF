import express from 'express';
import Reading from '../models/Reading.js';

const router = express.Router();

// Get latest readings
router.get('/latest', async (req, res) => {
  try {
    const latest = await Reading.findOne().sort({ timestamp: -1 });
    res.json(latest);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get historical data
router.get('/history', async (req, res) => {
  try {
    const { hours = 24 } = req.query;
    const since = new Date(Date.now() - hours * 60 * 60 * 1000);
    
    const readings = await Reading.find({ 
      timestamp: { $gte: since } 
    }).sort({ timestamp: 1 }).limit(100);
    
    res.json(readings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add new reading
router.post('/', async (req, res) => {
  try {
    const reading = new Reading(req.body);
    await reading.save();
    res.status(201).json(reading);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;