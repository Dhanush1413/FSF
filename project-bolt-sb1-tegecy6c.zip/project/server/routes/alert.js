import express from 'express';
import Log from '../models/Log.js';
import createCsvWriter from 'csv-writer';
import path from 'path';

const router = express.Router();

// Get all alerts
router.get('/', async (req, res) => {
  try {
    const alerts = await Log.find({ type: 'alert' })
      .sort({ timestamp: -1 })
      .limit(100);
    
    res.json(alerts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Export logs as CSV
router.get('/export', async (req, res) => {
  try {
    const { startDate, endDate, type } = req.query;
    
    let query = {};
    if (startDate && endDate) {
      query.timestamp = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    if (type) {
      query.type = type;
    }

    const logs = await Log.find(query).sort({ timestamp: -1 });

    const csvWriter = createCsvWriter.createObjectCsvWriter({
      path: path.resolve('exports/logs.csv'),
      header: [
        { id: 'deviceId', title: 'Device ID' },
        { id: 'action', title: 'Action' },
        { id: 'reason', title: 'Reason' },
        { id: 'type', title: 'Type' },
        { id: 'timestamp', title: 'Timestamp' }
      ]
    });

    await csvWriter.writeRecords(logs);
    res.download(path.resolve('exports/logs.csv'));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;