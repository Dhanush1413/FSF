import express from 'express';
import Settings from '../models/Settings.js';

const router = express.Router();

// Get all settings
router.get('/', async (req, res) => {
  try {
    const settings = await Settings.find();
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update setting
router.put('/:key', async (req, res) => {
  try {
    const { key } = req.params;
    const { value, description } = req.body;
    
    const setting = await Settings.findOneAndUpdate(
      { key },
      { value, description, lastUpdated: new Date() },
      { new: true, upsert: true }
    );

    res.json(setting);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;