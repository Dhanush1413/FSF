import mongoose from 'mongoose';
import Reading from './models/Reading.js';
import dotenv from 'dotenv';

dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/smart-agriculture');

function generateReading() {
  return {
    deviceId: 'farm-sensor-01',
    soilMoisture: Math.random() * 100, // 0-100%
    soilTemperature: 15 + Math.random() * 20, // 15-35°C
    airTemperature: 18 + Math.random() * 25, // 18-43°C
    humidity: 30 + Math.random() * 50, // 30-80%
    lightIntensity: Math.random() * 1000, // 0-1000 lux
  };
}

async function simulateSensor() {
  try {
    const reading = new Reading(generateReading());
    await reading.save();
    console.log('Generated reading:', {
      soilMoisture: reading.soilMoisture.toFixed(1),
      soilTemperature: reading.soilTemperature.toFixed(1),
      airTemperature: reading.airTemperature.toFixed(1),
      humidity: reading.humidity.toFixed(1),
      lightIntensity: reading.lightIntensity.toFixed(0)
    });
  } catch (error) {
    console.error('Simulation error:', error);
  }
}

// Generate readings every 5 seconds
setInterval(simulateSensor, 5000);

console.log('Sensor simulator started - generating readings every 5 seconds...');