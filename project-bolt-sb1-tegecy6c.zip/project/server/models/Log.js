import mongoose from 'mongoose';

const logSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true
  },
  action: {
    type: String,
    required: true
  },
  reason: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  type: {
    type: String,
    enum: ['irrigation', 'alert', 'system'],
    default: 'system'
  }
});

export default mongoose.model('Log', logSchema);