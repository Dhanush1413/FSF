import mongoose from 'mongoose';

const readingSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    default: 'farm-sensor-01'
  },
  soilMoisture: {
    type: Number,
    required: true
  },
  soilTemperature: {
    type: Number,
    required: true
  },
  airTemperature: {
    type: Number,
    required: true
  },
  humidity: {
    type: Number,
    required: true
  },
  lightIntensity: {
    type: Number,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('Reading', readingSchema);