import mongoose from 'mongoose';

const deviceSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    unique: true,
    default: 'irrigation-01'
  },
  name: {
    type: String,
    required: true,
    default: 'Main Irrigation System'
  },
  type: {
    type: String,
    required: true,
    default: 'irrigation'
  },
  status: {
    type: String,
    enum: ['ON', 'OFF'],
    default: 'OFF'
  },
  mode: {
    type: String,
    enum: ['manual', 'auto'],
    default: 'auto'
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('Device', deviceSchema);