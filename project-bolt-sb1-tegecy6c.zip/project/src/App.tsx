import React, { useState, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';
import Dashboard from './components/Dashboard';
import IrrigationControl from './components/IrrigationControl';
import WeatherForecast from './components/WeatherForecast';
import AlertsLogs from './components/AlertsLogs';
import Settings from './components/Settings';
import Navigation from './components/Navigation';
import { Reading, Device, WeatherData, Alert } from './types';

const socket: Socket = io('http://localhost:3001');

function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [sensorData, setSensorData] = useState<Reading | null>(null);
  const [devices, setDevices] = useState<Device[]>([]);
  const [weatherData, setWeatherData] = useState<WeatherData[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    // Socket event listeners
    socket.on('sensorUpdate', (data: Reading) => {
      setSensorData(data);
    });

    socket.on('deviceUpdate', (device: Device) => {
      setDevices(prev => 
        prev.map(d => d.deviceId === device.deviceId ? device : d)
      );
    });

    socket.on('newAlert', (alert: Alert) => {
      setAlerts(prev => [alert, ...prev.slice(0, 49)]);
    });

    return () => {
      socket.off('sensorUpdate');
      socket.off('deviceUpdate');
      socket.off('newAlert');
    };
  }, []);

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard sensorData={sensorData} />;
      case 'irrigation':
        return <IrrigationControl devices={devices} setDevices={setDevices} />;
      case 'weather':
        return <WeatherForecast weatherData={weatherData} setWeatherData={setWeatherData} />;
      case 'alerts':
        return <AlertsLogs alerts={alerts} setAlerts={setAlerts} />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard sensorData={sensorData} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <Navigation currentView={currentView} setCurrentView={setCurrentView} />
      <main className="container mx-auto px-4 py-8">
        {renderCurrentView()}
      </main>
    </div>
  );
}

export default App;