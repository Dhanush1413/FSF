import React, { useEffect, useState } from 'react';
import { Cloud, CloudRain, Sun, Thermometer, Droplets } from 'lucide-react';
import { WeatherData } from '../types';
import api from '../utils/api';

interface WeatherForecastProps {
  weatherData: WeatherData[];
  setWeatherData: React.Dispatch<React.SetStateAction<WeatherData[]>>;
}

const WeatherForecast: React.FC<WeatherForecastProps> = ({ weatherData, setWeatherData }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchWeatherData();
  }, []);

  const fetchWeatherData = async () => {
    try {
      setError(null);
      const response = await api.get('/weather/forecast');
      setWeatherData(response.data);
      setLoading(false);
    } catch (error: any) {
      setError(error.response?.data?.error || 'Failed to fetch weather data');
      setLoading(false);
    }
  };

  const getWeatherIcon = (description: string, rainProbability: number) => {
    if (rainProbability > 50) return CloudRain;
    if (description.includes('cloud')) return Cloud;
    return Sun;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-gray-800">Weather Forecast</h2>
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <Cloud className="w-12 h-12 text-red-400 mx-auto mb-3" />
          <p className="text-red-800 font-medium mb-2">Unable to load weather data</p>
          <p className="text-red-600 text-sm mb-4">{error}</p>
          <button
            onClick={fetchWeatherData}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Weather Forecast</h2>
        <button
          onClick={fetchWeatherData}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors text-sm"
        >
          Refresh
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {weatherData.map((forecast, index) => {
          const WeatherIcon = getWeatherIcon(forecast.description, forecast.rainProbability);
          const isToday = index === 0;
          
          return (
            <div
              key={index}
              className={`bg-white rounded-xl shadow-md p-6 border transition-transform hover:scale-105 ${
                isToday ? 'border-blue-200 bg-blue-50' : 'border-gray-100'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    {isToday ? 'Now' : new Date(forecast.timestamp).toLocaleDateString([], { 
                      month: 'short', 
                      day: 'numeric',
                      hour: '2-digit'
                    })}
                  </p>
                  <p className="text-xs text-gray-500 capitalize">{forecast.description}</p>
                </div>
                <WeatherIcon className={`w-8 h-8 ${
                  forecast.rainProbability > 50 ? 'text-blue-500' : 
                  forecast.description.includes('cloud') ? 'text-gray-500' : 'text-yellow-500'
                }`} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <Thermometer className="w-5 h-5 text-red-500 mx-auto mb-1" />
                  <p className="text-lg font-bold text-gray-800">{forecast.temperature.toFixed(1)}°C</p>
                  <p className="text-xs text-gray-500">Temperature</p>
                </div>
                <div className="text-center">
                  <Droplets className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                  <p className="text-lg font-bold text-gray-800">{forecast.humidity}%</p>
                  <p className="text-xs text-gray-500">Humidity</p>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Rain Probability</span>
                  <span className={`text-sm font-medium ${
                    forecast.rainProbability > 70 ? 'text-red-600' :
                    forecast.rainProbability > 30 ? 'text-yellow-600' : 'text-green-600'
                  }`}>
                    {forecast.rainProbability.toFixed(0)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      forecast.rainProbability > 70 ? 'bg-red-500' :
                      forecast.rainProbability > 30 ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${forecast.rainProbability}%` }}
                  />
                </div>
              </div>

              {forecast.rainProbability > 30 && (
                <div className="mt-3 text-xs text-yellow-800 bg-yellow-100 rounded-lg p-2">
                  ⚠ Rain expected - Auto irrigation may be suspended
                </div>
              )}
            </div>
          );
        })}
      </div>

      {weatherData.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <Cloud className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <p>No weather data available</p>
        </div>
      )}
    </div>
  );
};

export default WeatherForecast;