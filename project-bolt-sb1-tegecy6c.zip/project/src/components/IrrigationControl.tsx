import React, { useEffect, useState } from 'react';
import { Power, Settings, DropletIcon, AlertTriangle } from 'lucide-react';
import { Device, Alert } from '../types';
import api from '../utils/api';

interface IrrigationControlProps {
  devices: Device[];
  setDevices: React.Dispatch<React.SetStateAction<Device[]>>;
}

const IrrigationControl: React.FC<IrrigationControlProps> = ({ devices, setDevices }) => {
  const [logs, setLogs] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDevices();
    fetchLogs();
  }, []);

  const fetchDevices = async () => {
    try {
      const response = await api.get('/device');
      setDevices(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching devices:', error);
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    try {
      const response = await api.get('/device/irrigation-01/logs');
      setLogs(response.data);
    } catch (error) {
      console.error('Error fetching logs:', error);
    }
  };

  const updateDevice = async (deviceId: string, updates: Partial<Device>) => {
    try {
      const response = await api.put(`/device/${deviceId}`, updates);
      setDevices(prev => 
        prev.map(d => d.deviceId === deviceId ? response.data : d)
      );
      fetchLogs(); // Refresh logs after update
    } catch (error) {
      console.error('Error updating device:', error);
    }
  };

  const irrigationDevice = devices.find(d => d.deviceId === 'irrigation-01') || {
    deviceId: 'irrigation-01',
    name: 'Main Irrigation System',
    type: 'irrigation',
    status: 'OFF' as const,
    mode: 'auto' as const,
    lastUpdated: new Date()
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Irrigation Control</h2>
      </div>

      {/* Main Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <DropletIcon className="w-6 h-6 text-blue-500" />
              <h3 className="text-lg font-semibold text-gray-800">{irrigationDevice.name}</h3>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${
              irrigationDevice.status === 'ON' 
                ? 'bg-green-100 text-green-800' 
                : 'bg-gray-100 text-gray-800'
            }`}>
              {irrigationDevice.status}
            </div>
          </div>

          {/* Status Display */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Power className={`w-8 h-8 mx-auto mb-2 ${
                irrigationDevice.status === 'ON' ? 'text-green-500' : 'text-gray-400'
              }`} />
              <p className="text-sm font-medium text-gray-600">Status</p>
              <p className="text-lg font-bold text-gray-800">{irrigationDevice.status}</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Settings className={`w-8 h-8 mx-auto mb-2 ${
                irrigationDevice.mode === 'auto' ? 'text-blue-500' : 'text-orange-500'
              }`} />
              <p className="text-sm font-medium text-gray-600">Mode</p>
              <p className="text-lg font-bold text-gray-800 capitalize">{irrigationDevice.mode}</p>
            </div>
          </div>

          {/* Controls */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium text-gray-700">Control Mode</span>
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => updateDevice(irrigationDevice.deviceId, { mode: 'auto' })}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    irrigationDevice.mode === 'auto'
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  Auto
                </button>
                <button
                  onClick={() => updateDevice(irrigationDevice.deviceId, { mode: 'manual' })}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    irrigationDevice.mode === 'manual'
                      ? 'bg-white text-orange-600 shadow-sm'
                      : 'text-gray-600 hover:text-orange-600'
                  }`}
                >
                  Manual
                </button>
              </div>
            </div>

            {irrigationDevice.mode === 'manual' && (
              <div className="flex space-x-3">
                <button
                  onClick={() => updateDevice(irrigationDevice.deviceId, { status: 'ON' })}
                  disabled={irrigationDevice.status === 'ON'}
                  className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-green-300 text-white py-3 rounded-lg font-medium transition-colors"
                >
                  Turn ON
                </button>
                <button
                  onClick={() => updateDevice(irrigationDevice.deviceId, { status: 'OFF' })}
                  disabled={irrigationDevice.status === 'OFF'}
                  className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-red-300 text-white py-3 rounded-lg font-medium transition-colors"
                >
                  Turn OFF
                </button>
              </div>
            )}

            {irrigationDevice.mode === 'auto' && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-blue-600" />
                  <p className="text-sm text-blue-800">
                    <strong>Auto mode:</strong> System will automatically control irrigation based on soil moisture levels.
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="mt-4 text-sm text-gray-500">
            Last updated: {new Date(irrigationDevice.lastUpdated).toLocaleString()}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {logs.map((log, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-2 h-2 rounded-full mt-2 ${
                  log.action.includes('ON') ? 'bg-green-500' : 
                  log.action.includes('OFF') ? 'bg-red-500' : 'bg-blue-500'
                }`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800">{log.action}</p>
                  <p className="text-xs text-gray-600">{log.reason}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(log.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
            {logs.length === 0 && (
              <p className="text-gray-500 text-center py-8">No recent activity</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default IrrigationControl;