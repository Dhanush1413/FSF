import React, { useEffect, useState } from 'react';
import { Download, AlertTriangle, Info, Wrench, Filter } from 'lucide-react';
import { Alert } from '../types';
import api from '../utils/api';

interface AlertsLogsProps {
  alerts: Alert[];
  setAlerts: React.Dispatch<React.SetStateAction<Alert[]>>;
}

const AlertsLogs: React.FC<AlertsLogsProps> = ({ alerts, setAlerts }) => {
  const [logs, setLogs] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    fetchAlerts();
  }, []);

  const fetchAlerts = async () => {
    try {
      const response = await api.get('/alert');
      setAlerts(response.data);
      setLogs(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching alerts:', error);
      setLoading(false);
    }
  };

  const exportLogs = async () => {
    try {
      const response = await api.get('/alert/export', { 
        responseType: 'blob',
        params: { type: filter !== 'all' ? filter : undefined }
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `logs-${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error exporting logs:', error);
    }
  };

  const getIconForType = (type: string, action: string) => {
    if (type === 'alert') return AlertTriangle;
    if (type === 'irrigation') return Wrench;
    return Info;
  };

  const getColorForType = (type: string, action: string) => {
    if (type === 'alert') return 'text-red-500 bg-red-50 border-red-200';
    if (action.includes('ON')) return 'text-green-500 bg-green-50 border-green-200';
    if (action.includes('OFF')) return 'text-gray-500 bg-gray-50 border-gray-200';
    return 'text-blue-500 bg-blue-50 border-blue-200';
  };

  const filteredLogs = logs.filter(log => 
    filter === 'all' || log.type === filter
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Alerts & Logs</h2>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-500" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="all">All Types</option>
              <option value="alert">Alerts</option>
              <option value="irrigation">Irrigation</option>
              <option value="system">System</option>
            </select>
          </div>
          <button
            onClick={exportLogs}
            className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors text-sm"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow-md p-6 border border-red-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Alerts</p>
              <p className="text-2xl font-bold text-red-600">
                {logs.filter(log => log.type === 'alert').length}
              </p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 border border-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Irrigation Events</p>
              <p className="text-2xl font-bold text-blue-600">
                {logs.filter(log => log.type === 'irrigation').length}
              </p>
            </div>
            <Wrench className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 border border-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">System Events</p>
              <p className="text-2xl font-bold text-green-600">
                {logs.filter(log => log.type === 'system').length}
              </p>
            </div>
            <Info className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>

      {/* Logs List */}
      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">
            Recent Activity ({filteredLogs.length})
          </h3>
        </div>
        
        <div className="max-h-96 overflow-y-auto">
          {filteredLogs.map((log, index) => {
            const Icon = getIconForType(log.type, log.action);
            const colorClass = getColorForType(log.type, log.action);
            
            return (
              <div
                key={index}
                className="flex items-start space-x-4 p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors"
              >
                <div className={`p-2 rounded-lg border ${colorClass}`}>
                  <Icon className="w-5 h-5" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-800">{log.action}</p>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      log.type === 'alert' ? 'bg-red-100 text-red-800' :
                      log.type === 'irrigation' ? 'bg-blue-100 text-blue-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {log.type}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{log.reason}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    {new Date(log.timestamp).toLocaleString()} • Device: {log.deviceId}
                  </p>
                </div>
              </div>
            );
          })}
          
          {filteredLogs.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Info className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p>No {filter !== 'all' ? filter : ''} logs found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AlertsLogs;