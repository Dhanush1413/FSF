import React, { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { Thermometer, Droplets, Sun, Wind, Zap } from 'lucide-react';
import { Reading } from '../types';
import api from '../utils/api';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface DashboardProps {
  sensorData: Reading | null;
}

const Dashboard: React.FC<DashboardProps> = ({ sensorData }) => {
  const [historicalData, setHistoricalData] = useState<Reading[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistoricalData();
  }, []);

  const fetchHistoricalData = async () => {
    try {
      const response = await api.get('/sensor/history?hours=1');
      setHistoricalData(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching historical data:', error);
      setLoading(false);
    }
  };

  const chartData = {
    labels: historicalData.map(reading => 
      new Date(reading.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    ),
    datasets: [
      {
        label: 'Soil Moisture (%)',
        data: historicalData.map(reading => reading.soilMoisture),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        yAxisID: 'y'
      },
      {
        label: 'Air Temperature (°C)',
        data: historicalData.map(reading => reading.airTemperature),
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        yAxisID: 'y1'
      },
      {
        label: 'Humidity (%)',
        data: historicalData.map(reading => reading.humidity),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        yAxisID: 'y'
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    plugins: {
      title: {
        display: true,
        text: 'Sensor Data - Last Hour'
      }
    },
    scales: {
      x: {
        display: true,
        title: {
          display: true,
          text: 'Time'
        }
      },
      y: {
        type: 'linear' as const,
        display: true,
        position: 'left' as const,
        title: {
          display: true,
          text: 'Percentage (%)'
        }
      },
      y1: {
        type: 'linear' as const,
        display: true,
        position: 'right' as const,
        title: {
          display: true,
          text: 'Temperature (°C)'
        },
        grid: {
          drawOnChartArea: false,
        }
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
        <div className="text-sm text-gray-500">
          Last updated: {sensorData ? new Date(sensorData.timestamp).toLocaleString() : 'Never'}
        </div>
      </div>

      {/* Current Readings */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl shadow-md p-6 border border-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Soil Moisture</p>
              <p className="text-2xl font-bold text-green-600">
                {sensorData ? sensorData.soilMoisture.toFixed(1) : '--'}%
              </p>
            </div>
            <Droplets className="w-8 h-8 text-green-500" />
          </div>
          {sensorData && sensorData.soilMoisture < 30 && (
            <div className="mt-2 text-xs text-red-600 font-medium">⚠ Low moisture</div>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-orange-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Soil Temp</p>
              <p className="text-2xl font-bold text-orange-600">
                {sensorData ? sensorData.soilTemperature.toFixed(1) : '--'}°C
              </p>
            </div>
            <Thermometer className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-red-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Air Temp</p>
              <p className="text-2xl font-bold text-red-600">
                {sensorData ? sensorData.airTemperature.toFixed(1) : '--'}°C
              </p>
            </div>
            <Thermometer className="w-8 h-8 text-red-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Humidity</p>
              <p className="text-2xl font-bold text-blue-600">
                {sensorData ? sensorData.humidity.toFixed(1) : '--'}%
              </p>
            </div>
            <Wind className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 border border-yellow-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Light</p>
              <p className="text-2xl font-bold text-yellow-600">
                {sensorData ? sensorData.lightIntensity.toFixed(0) : '--'} lux
              </p>
            </div>
            <Sun className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <Line data={chartData} options={chartOptions} />
      </div>
    </div>
  );
};

export default Dashboard;