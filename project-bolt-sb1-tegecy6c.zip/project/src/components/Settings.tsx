import React, { useState, useEffect } from 'react';
import { Save, Key, Gauge, AlertCircle } from 'lucide-react';
import { Settings as SettingsType } from '../types';
import api from '../utils/api';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState<SettingsType[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [localValues, setLocalValues] = useState<Record<string, any>>({});

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await api.get('/settings');
      setSettings(response.data);
      
      // Initialize local values
      const values: Record<string, any> = {};
      response.data.forEach((setting: SettingsType) => {
        values[setting.key] = setting.value;
      });
      setLocalValues(values);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching settings:', error);
      setLoading(false);
    }
  };

  const saveSetting = async (key: string, value: any, description: string) => {
    setSaving(key);
    try {
      await api.put(`/settings/${key}`, { value, description });
      
      // Update settings list
      setSettings(prev => 
        prev.find(s => s.key === key)
          ? prev.map(s => s.key === key ? { ...s, value, lastUpdated: new Date() } : s)
          : [...prev, { key, value, description, lastUpdated: new Date() }]
      );
      
      setSaving(null);
    } catch (error) {
      console.error('Error saving setting:', error);
      setSaving(null);
    }
  };

  const settingConfigs = [
    {
      key: 'soil_moisture_threshold',
      label: 'Soil Moisture Threshold (%)',
      description: 'Minimum soil moisture level before irrigation activates',
      type: 'number',
      min: 10,
      max: 80,
      icon: Gauge
    },
    {
      key: 'openweather_api_key',
      label: 'OpenWeather API Key',
      description: 'API key for weather forecast integration',
      type: 'text',
      icon: Key,
      sensitive: true
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Settings</h2>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start space-x-3">
          <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h3 className="text-sm font-medium text-blue-800">Configuration Notes</h3>
            <ul className="text-sm text-blue-700 mt-1 space-y-1">
              <li>• Changes to thresholds take effect immediately</li>
              <li>• Weather API key is required for forecast features</li>
              <li>• All settings are automatically saved</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {settingConfigs.map((config) => {
          const Icon = config.icon;
          const currentValue = localValues[config.key] ?? '';
          const existingSetting = settings.find(s => s.key === config.key);
          
          return (
            <div key={config.key} className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-start space-x-4">
                <div className="p-3 bg-green-100 rounded-lg">
                  <Icon className="w-6 h-6 text-green-600" />
                </div>
                
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">
                    {config.label}
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">
                    {config.description}
                  </p>
                  
                  <div className="space-y-3">
                    <div>
                      <input
                        type={config.sensitive ? 'password' : config.type}
                        value={currentValue}
                        onChange={(e) => setLocalValues(prev => ({
                          ...prev,
                          [config.key]: config.type === 'number' ? Number(e.target.value) : e.target.value
                        }))}
                        min={config.min}
                        max={config.max}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder={config.sensitive ? '••••••••••••' : `Enter ${config.label.toLowerCase()}`}
                      />
                    </div>
                    
                    <button
                      onClick={() => saveSetting(config.key, currentValue, config.description)}
                      disabled={saving === config.key}
                      className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
                    >
                      <Save className="w-4 h-4" />
                      <span>{saving === config.key ? 'Saving...' : 'Save'}</span>
                    </button>
                  </div>
                  
                  {existingSetting && (
                    <p className="text-xs text-gray-500 mt-3">
                      Last updated: {new Date(existingSetting.lastUpdated).toLocaleString()}
                    </p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Current Settings Overview */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Current Configuration</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {settings.map((setting) => (
            <div key={setting.key} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600 capitalize">
                  {setting.key.replace(/_/g, ' ')}
                </span>
                <span className="text-sm text-gray-800">
                  {setting.key.includes('api_key') 
                    ? '••••••••••••' 
                    : String(setting.value)
                  }
                  {setting.key.includes('threshold') && '%'}
                </span>
              </div>
            </div>
          ))}
        </div>
        
        {settings.length === 0 && (
          <p className="text-gray-500 text-center py-4">No settings configured</p>
        )}
      </div>
    </div>
  );
};

export default Settings;