export interface Reading {
  _id?: string;
  deviceId: string;
  soilMoisture: number;
  soilTemperature: number;
  airTemperature: number;
  humidity: number;
  lightIntensity: number;
  timestamp: Date;
}

export interface Device {
  _id?: string;
  deviceId: string;
  name: string;
  type: string;
  status: 'ON' | 'OFF';
  mode: 'manual' | 'auto';
  lastUpdated: Date;
}

export interface WeatherData {
  timestamp: Date;
  temperature: number;
  humidity: number;
  description: string;
  rainProbability: number;
  rain: number;
}

export interface Alert {
  _id?: string;
  deviceId: string;
  action: string;
  reason: string;
  timestamp: Date;
  type: 'irrigation' | 'alert' | 'system';
}

export interface Settings {
  _id?: string;
  key: string;
  value: any;
  description: string;
  lastUpdated: Date;
}